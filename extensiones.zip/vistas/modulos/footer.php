<footer class="main-footer">
	
	<strong>Trabajo integrador.</strong>



</footer>